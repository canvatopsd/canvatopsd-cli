# CanvaToPSD CLI

默认连接 **prod** `https://canvatopsd.com/api`。npm 启动器需要 Node.js 22.16+，业务命令由 Rust 原生程序执行，支持标准 shell 的 AI Agent。业务结果默认就是 JSON，无需 `--json`。

## 常用流程

CLI 2.3 起，只需记住 `convert` 返回的一个 `taskId`，后续全部使用同一个 `TASK`。

```sh
canvatopsd convert 'CANVA_PUBLIC_VIEW_URL'
canvatopsd preview TASK --out .tmp/artifacts/preview.webp
canvatopsd checkout TASK
# 用户完成付款后：
canvatopsd download TASK --out .tmp/artifacts/design.psd
```

`convert` 提交设计、发现页面并等待预览就绪。单页自动处理；多页通过 `--pages 1,3` 明确选择，不会默认猜选。多页后续操作使用设计中的页码，无需查找内部转换 ID：

```sh
canvatopsd convert 'CANVA_PUBLIC_VIEW_URL' --pages 1,3
canvatopsd preview TASK --page 3 --out .tmp/artifacts/page3.webp
canvatopsd checkout TASK --page 3
canvatopsd download TASK --page 3 --out .tmp/artifacts/page3.psd
```

`TASK` 始终为同一个任务 ID。`--page` 是从 1 开始的设计页码，不再表示文件清单中的 pageId；只有需要指定内部文件页时才使用高级选项 `--artifact-page ID`（preview/download）。选择了多个页面却未指定页码时，明确报错并列出可用页码。

## 等待、状态与恢复

`convert --seconds 300` 的等待时限覆盖发现页面、选页提交、状态查询和轮询；初始创建请求另受全局 `--timeout` 约束。超时不取消转换，错误中返回 `taskId` 和 `submitKey`。用 `wait TASK` 继续等待，`status TASK` 查看所选页码、逐页状态和是否需要输入。多页全部就绪才返回 ready，不会因其中一页就绪提前结束。

未指定 `--pages` 的多页设计会报 `page_selection_required` 并保留任务；使用 `select TASK 1,3` 后继续 `wait TASK`。已有任务不需要重新 convert。

`convert` 的首次提交键在请求前写入 stderr，并随结果或错误返回；响应不确定时，使用原 URL、页码与 `--key UUID` 重试。选页提交使用任务 ID 作为稳定幂等键；已确认的页码与新请求不一致时明确报错，不重新创建另一组页面。仅恢复等待用 wait，无需重提。

## 常用命令

| 命令                             | 用途                                                 |
| -------------------------------- | ---------------------------------------------------- |
| `convert URL [--pages 1,3]`      | 提交并等待预览，返回后续共用的任务 ID                |
| `status TASK` / `wait TASK`      | 查看所选页面状态 / 有界等待全部就绪                  |
| `preview TASK --out FILE`        | 保存预览                                             |
| `checkout TASK`                  | 创建付款链接，由用户付款                             |
| `download TASK --out FILE`       | 同步支付状态并下载，校验大小与 SHA-256               |
| `pages TASK` / `select TASK 1,3` | 需要分步操作时查看与选择页面                         |
| `payment TASK` / `confirm TASK`  | 单独同步支付 / 确认已授权付款；后者可能 capture 款项 |
| `files TASK`                     | 查看已付款文件                                       |
| `create URL`                     | 只提交任务，不执行后续发现与等待                     |
| `doctor`                         | 检查 API 路由与任务凭据协议                          |

`preview`、`checkout`、`download`、`files`、`payment`、`confirm` 均支持 `--page 页码`。常用流程不需要单独执行 payment。

`checkoutUrl` 是 CanvaToPSD 托管付款入口，应原样交给用户，不替换成历史 PayPal 地址。它在实际打开的浏览器中建立任务 Cookie 后进入同一笔 PayPal 订单；已有订单也适用，不要求用户预先打开私有任务链接。入口有效期为 7 天，过期后重新运行 `checkout` 获取新入口，不重复转换或新建付款订单。具体协议由 API 单元的 `doc/task-return-routing.md` 维护。

`convert`、`create`、`select` 的 `--dry-run` 只本机校验，不写凭据或提交任务。`checkout --dry-run` 读取实时报价但不创建付款。业务状态每次实时读取，不保存“最近一个任务”或缓存报价。

下载默认取 `page-0001.psd`；字体使用 `--file fonts.zip` 或 `--file fonts.txt`。图层预览使用 `--file preview-layers.json` / `preview-layers.webp`。目标文件存在时明确报错。预览不代表已付款，下载成功不代表已验证 Photoshop 原生打开或语义可编辑性。

## 任务凭据与可选邮箱

不需要账号、API Key 或邮箱。CLI 为每次新提交生成独立随机 Token，在请求发出前写入本机 0600 配置文件；API 仅保存哈希，并返回该任务的 Cookie。Token 不出现在命令输出中。`--key UUID` 重试会复用本机预存 Token；`auth status` 可列出保存的提交键。不能只凭提交键换发访问凭据。

`--email EMAIL` 可接收邮件通知；不填时，创建、转换完成、人工输入和付款均不生成邮件通知。需要输入时通过 `status` / `wait` 获知。原凭据在任务就绪、付款后继续有效，父任务凭据可访问直接子任务。CLI 只发送目标任务或其父任务的凭据，`select`、`pages` 和父任务 `status` 的响应会保存授权关联；旧版已经创建的子任务，先查询一次父任务 `status` 即可补齐关联。

备份或换机器：

```sh
canvatopsd auth export TASK .tmp/artifacts/task-access.json
# 在同一服务环境的新机器中：
canvatopsd auth import /absolute/task-access.json
```

导出文件含单个任务的秘密凭据，权限 0600，不覆盖已有文件；不要上传 Git 或贴到聊天。子任务使用父任务授权时，导出父任务即可。导入前须选择与文件一致的服务端点。原有邮件私密链接文件仍可导入，包括 `zh-tw`、`pt-br` 等语言前缀。`auth clear` 同时清除所选端点的 Cookie、重试 Token 和父子授权关联。无邮箱且本机凭据和备份均丢失时，不能自行恢复权限。

付款仍按任务进行，Key/邮箱都不是付款条件。用户批准付款后可查询 `payment TASK`；只有获得确认付款授权时执行 `confirm TASK`。支付 webhook 可更新状态，CLI 持有的任务凭据继续用于下载。

3.0 保留此流程，要求 API 已支持 `taskToken` 和可选邮箱；旧 API 会明确拒绝请求。CLI 默认仍指向 prod，API 的 prod 发布须独立执行。

## 安装与 Skill

3.0.x 已迁移为 Rust；当前仅验收 macOS ARM64 归档，尚未公开发布到 npm。各分发渠道的可用版本、平台与运行要求见 [产品事实页](product-facts.md)。以下 npm 注册表命令适用于正式发布后。

npm 包名为 `@canvatopsd/cli`，命令名为 `canvatopsd`。包发布到 npm 后可直接运行：

```sh
npx --yes @canvatopsd/cli --help
```

也可以全局安装，再安装随包提供的 Skill：

```sh
npm install -g @canvatopsd/cli
canvatopsd --version
canvatopsd skill install codex
```

Skill 支持 `codex`、`claude-code`、`cursor`、`copilot`、`agents`，分别安装到用户目录中的 `.codex/skills`、`.claude/skills`、`.cursor/skills`、`.copilot/skills`、`.agents/skills`。默认 codex；自定义项目级目录用 `canvatopsd skill install --dir /path/to/project/.agents/skills`。已有 Skill 明确报错，不覆盖人工修改。

Skill 源码在 `cli/skills/canvatopsd/SKILL.md`。任何支持通用 Agent Skills 和 shell 的 Agent 都可使用；不支持自动发现时，让它读取该文件即可。

## 配置与高级命令

无需初始化即可用 prod。`canvatopsd init` 保存 prod；`canvatopsd init http://127.0.0.1:8080/api` 显式切换 local。临时切换使用全局 `--base-url URL`。`--origin` 仅用于本机代理的 Origin 校验；`--timeout` 是单请求秒数，默认 30。

配置优先级为参数 > 环境变量 > 配置文件 > 默认值。`CANVATOPSD_BASE_URL`、`CANVATOPSD_ORIGIN` 对应连接参数。`CANVATOPSD_CONFIG` 默认 `~/.config/canvatopsd/config.json`，只保存连接配置、Cookie 与提交重试 Token，权限 0600。更新配置时使用文件锁，在锁内重读最新内容并只合并本次变更；占用时明确返回 `ELOCKED`，可在占用命令完成后重试。创建结果不确定时仍复用 `--key`。多个 Agent 可用 `CANVATOPSD_CONFIG` 隔离凭据。

普通 Web 调用不需要操作员密钥。直接 API 操作员查询使用 `CANVATOPSD_OPERATOR_TOKEN`；直接 API 客户命令还需 `CANVATOPSD_PROXY_TOKEN`。操作员身份不替代任务 Cookie。HTTPS 使用系统信任库，不关闭证书校验。

```sh
canvatopsd resolve 'CANVA_URL'
canvatopsd --base-url http://127.0.0.1:8080 operator task-list --offset 0
canvatopsd request /task/status --body .tmp/request.json
```

`operator notification-status TASK` 查询通知记录。任务列表每页 100 条。`request` 始终 POST，`--operator` 加操作员授权，`--out FILE` 保存二进制；请求结构由服务提供方维护。raw 命令可改变业务数据，不是只读调试入口。

## 输出与错误

成功 stdout 为 `{"ok":true,"data":...}`，退出码 0；失败为 `{"ok":false,"error":{"code":"...","message":"..."}}`，退出码 1。API 错误还带 HTTP `status`，提交错误还带 `submitKey`。帮助和版本为文本，stderr 仅用于提交键等诊断。

401/403 用匹配环境的任务凭据备份或邮件私密链接恢复权限：文件需包含 `/task/UUID#access=...` 完整地址。不要输出私密链接或配置内容。409 读取任务状态并处理 code；`wait_timeout` 可继续查询，不会取消后台任务。`doctor` 通过只读的 `POST /task/protocol/read` 检查真实 API 路由、数据库访问与 `taskToken` / 可选邮箱协议；不支持的 API 或未同步路由的 Web 会明确报错。通过检查不代表具体任务权限、Runner、支付或交付已通过。

2.0 将旧的 `task create/status/wait`、`page list/request`、`preview list/download`、`delivery list/download` 等入口替换为上面的短命令；旧参数不保留兼容层。

## Agent 发现与自助使用

完整英文命令与选项由实际 Rust 定义生成，见 [命令参考](command-reference.md)；产品能力与分发版本区别见 [产品事实页](product-facts.md)。`discover` 的 `data.product` 提供能力、格式、服务需求和包内文档路径，`data.command` 继续提供命令树。

```sh
canvatopsd --help
canvatopsd create --help
canvatopsd discover
canvatopsd discover 'skill install'
canvatopsd skill show
canvatopsd skill status codex
# 检查并确认可替换本机 Skill 后：
canvatopsd skill install codex --replace
```

`discover [command]` 离线返回 JSON 命令树，参数、选项、必填与默认值直接来自实际命令定义，并附示例和副作用说明。嵌套命令路径需要引号。它不读取凭据、不连接服务，也不提交任务；帮助中的示例占位符须替换后再执行。

`skill show` 以 JSON 返回随包附带的入口文档；`skill status [agent]` 对比安装位置与随包文件，报告缺失或差异文件。`current` 仅表示随包文件一致，不代表 Agent 已加载该 Skill、PATH 正确或服务健康。命令在目标 Agent 的执行终端中运行成功，才能证明该终端可找到 CLI。安装或更新后，新建 Agent 会话以刷新发现列表。

`skill install --replace` 显式替换整个目标 Skill 目录（含人工修改）；默认仍拒绝覆盖。安装支持 `codex`、`claude-code`、`cursor`、`copilot`、`agents` 或自定义 `--dir`，Codex 设置了 `CODEX_HOME` 时使用其 `skills/`。入口 `SKILL.md` 保留任务选择、最短流程及交付条件，凭据恢复和高级操作按需读取 `references/operations.md`。

项目可在自己已有的 Agent 指引中添加一句：“Canva 转 PSD、CanvaToPSD 任务预览与下载使用 canvatopsd Skill；命令索引运行 canvatopsd discover。”本仓库入口见 `cli/skills/canvatopsd/SKILL.md`。无需为此添加 MCP；远端或无 Shell 的接入另行评估。
